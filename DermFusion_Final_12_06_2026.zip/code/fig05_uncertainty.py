#!/usr/bin/env python3
"""
DermFusion — Figure 4: Uncertainty Quantification (6-panel)
=============================================================
Reproduces Fig4_Uncertainty.png from the paper.

Paper values (Tab. referral_perf, Tab. tau_sweep, §VI):
  tau* = 0.30
  Coverage retained  = 68%    →  0.68 × 2003 ≈ 1362 samples
  Coverage referred  = 32%    →  0.32 × 2003 ≈  641 samples
  Acc retained       = 96.40%
  MEL Sens retained  = 97.10%
  Baseline acc       = 87.82%
  Baseline MEL Sens  = 88.80%
  T_mc               = 10 passes
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import warnings
warnings.filterwarnings("ignore")

np.random.seed(42)
rng = np.random.default_rng(42)

# ─── Constants from paper ─────────────────────────────────────────────────────
TAU_STAR  = 0.30
N_TEST    = 2003
N_CORRECT = int(round(0.8782 * N_TEST))   # 87.82% accuracy
N_WRONG   = N_TEST - N_CORRECT

N_RETAINED = int(round(0.68 * N_TEST))    # 68% retained
N_REFERRED = N_TEST - N_RETAINED

# Simulate scalar variance σ²_unc for correct and incorrect predictions
# Correct: concentrated near 0; Incorrect: spread toward high variance
var_correct   = rng.gamma(shape=0.4, scale=0.08, size=N_CORRECT)
var_incorrect = rng.gamma(shape=1.5, scale=0.18, size=N_WRONG)
# Clip to [0, 1] range
var_correct   = np.clip(var_correct,   0, 1)
var_incorrect = np.clip(var_incorrect, 0, 1)

# Referral threshold sensitivity sweep (Tab. tau_sweep)
TAU_VALS   = [0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40]
COVERAGE   = [94.2, 89.6, 83.1, 76.4, 68.0, 61.2, 53.5]
ACC_RET    = [88.5, 90.1, 91.8, 93.5, 96.4, 97.0, 97.8]
MEL_SENS   = [86.1, 89.4, 93.0, 95.2, 97.1, 97.8, 98.1]
UTIL       = [0.591, 0.601, 0.641, 0.666, 0.702, 0.698, 0.679]

# 5-fold CV stability (Tab. cv_results)
FOLD_ACC   = [87.9, 88.6, 89.4, 88.1, 88.7]
FOLD_AUC   = [0.978, 0.982, 0.985, 0.979, 0.983]
FOLD_DICE  = [0.921, 0.927, 0.933, 0.925, 0.929]

CLASSES = ["MEL", "NV", "BCC", "AKIEC", "BKL", "DF", "VASC"]

# Per-class variances (MEL and AKIEC are harder → higher uncertainty)
class_correct_var = {
    "MEL": rng.gamma(0.5, 0.12, 182),  "NV":    rng.gamma(0.3, 0.06, 1224),
    "BCC": rng.gamma(0.3, 0.07, 92),   "AKIEC": rng.gamma(0.6, 0.14, 46),
    "BKL": rng.gamma(0.4, 0.09, 162),  "DF":    rng.gamma(0.3, 0.07, 21),
    "VASC":rng.gamma(0.25,0.05, 32)
}
class_wrong_var = {
    "MEL": rng.gamma(1.6, 0.19, 23),   "NV":    rng.gamma(1.3, 0.16, 137),
    "BCC": rng.gamma(1.2, 0.15, 1),    "AKIEC": rng.gamma(1.7, 0.20, 21),
    "BKL": rng.gamma(1.5, 0.18, 61),   "DF":    rng.gamma(1.2, 0.15, 1),
    "VASC":rng.gamma(1.1, 0.12, 0)
}

PALETTE = {
    "correct":  "#2E7D32", "incorrect": "#C62828",
    "retained": "#1565C0", "referred":  "#E65100",
    "tau":      "#FF6F00", "utility":   "#6A1B9A",
}

# ─── Figure ──────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(18, 12), facecolor="white")
gs  = GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)

# ── A: Variance distribution correct vs incorrect ─────────────────────────
ax1 = fig.add_subplot(gs[0, 0])
bins = np.linspace(0, 1.0, 45)
ax1.hist(var_correct,   bins=bins, alpha=0.72, color=PALETTE["correct"],
         label=f"Correct ({N_CORRECT})", density=True, edgecolor="white", lw=0.3)
ax1.hist(var_incorrect, bins=bins, alpha=0.72, color=PALETTE["incorrect"],
         label=f"Incorrect ({N_WRONG})", density=True, edgecolor="white", lw=0.3)
ax1.axvline(TAU_STAR, color=PALETTE["tau"], lw=2.4, ls="--",
            label=f"τ* = {TAU_STAR}")
ax1.set(xlabel="Predictive Variance σ²_unc", ylabel="Density",
        title="A  Variance: Correct vs Incorrect Predictions")
ax1.legend(fontsize=9.5); ax1.grid(alpha=0.22)

# ── B: Retained accuracy vs tau (from sweep) ──────────────────────────────
ax2 = fig.add_subplot(gs[0, 1])
ax2.plot(TAU_VALS, ACC_RET, "o-", color=PALETTE["retained"],
         lw=2.2, ms=7, label="Retained Acc (%)")
ax2.axvline(TAU_STAR, color=PALETTE["tau"], lw=2.0, ls="--",
            label=f"τ* = {TAU_STAR}")
ax2.axhline(96.4, color="black", lw=1.0, ls=":", alpha=0.5,
            label="96.4% at τ*=0.30")
ax2.scatter([TAU_STAR], [96.4], s=100, zorder=5, color=PALETTE["tau"],
            edgecolors="black", lw=0.8)
ax2.set(xlabel="Referral Threshold τ", ylabel="Retained-Case Accuracy (%)",
        title="B  Accuracy Increases as τ Tightens")
ax2.set_ylim(87, 99); ax2.legend(fontsize=9); ax2.grid(alpha=0.22)

# ── C: Coverage-accuracy tradeoff ─────────────────────────────────────────
ax3 = fig.add_subplot(gs[0, 2])
ax3.plot(COVERAGE, ACC_RET, "s-", color=PALETTE["retained"],
         lw=2.2, ms=7, label="Accuracy vs Coverage")
# annotate operating point
idx_star = COVERAGE.index(68.0)
ax3.scatter([68.0], [96.4], s=130, zorder=5, color=PALETTE["tau"],
            edgecolors="black", lw=1.0,
            label=f"τ*=0.30: 96.4% @ 68%")
for i, (cov, acc) in enumerate(zip(COVERAGE, ACC_RET)):
    ax3.annotate(f"τ={TAU_VALS[i]}", (cov, acc),
                 xytext=(3, 3), textcoords="offset points", fontsize=7.5)
ax3.set(xlabel="Coverage (%)", ylabel="Retained-Case Accuracy (%)",
        title="C  Coverage–Accuracy Tradeoff")
ax3.set_xlim(50, 97); ax3.set_ylim(87, 99)
ax3.legend(fontsize=9); ax3.grid(alpha=0.22)

# ── D: Per-class MC variance histograms ──────────────────────────────────
ax4 = fig.add_subplot(gs[1, 0])
cls_colors = ["#C62828","#1565C0","#2E7D32","#F57F17",
              "#6A1B9A","#00838F","#558B2F"]
bins_cls = np.linspace(0, 0.8, 25)
for i, cls in enumerate(CLASSES):
    vc = np.clip(class_correct_var[cls], 0, 0.8)
    ax4.hist(vc, bins=bins_cls, alpha=0.55, density=True,
             color=cls_colors[i], label=cls, edgecolor="none")
ax4.axvline(TAU_STAR, color=PALETTE["tau"], lw=2.0, ls="--",
            label=f"τ* = {TAU_STAR}")
ax4.set(xlabel="σ²_unc (correct predictions)", ylabel="Density",
        title="D  Per-Class Variance Histograms (Correct)")
ax4.legend(fontsize=8, ncol=2); ax4.grid(alpha=0.22)

# ── E: Accuracy vs referral rate ─────────────────────────────────────────
ax5 = fig.add_subplot(gs[1, 1])
ref_rates = [100 - c for c in COVERAGE]          # referral %
ax5.plot(ref_rates, ACC_RET, "D-", color=PALETTE["utility"],
         lw=2.2, ms=7)
ax5.axvline(32.0, color=PALETTE["tau"], lw=2.0, ls="--",
            label=f"32% referred at τ*=0.30")
ax5.scatter([32.0], [96.4], s=130, zorder=5, color=PALETTE["tau"],
            edgecolors="black", lw=1.0)
ax5.set(xlabel="Referral Rate (%)", ylabel="Accuracy on Retained (%)",
        title="E  Accuracy vs Referral Rate")
ax5.set_xlim(0, 50); ax5.set_ylim(87, 99)
ax5.legend(fontsize=9); ax5.grid(alpha=0.22)

# ── F: Triage summary bar ─────────────────────────────────────────────────
ax6 = fig.add_subplot(gs[1, 2])
categories  = ["Baseline\n(All 2003)", "Retained\n(68%, n=1362)", "Referred\n(32%, n=641)"]
acc_vals    = [87.82, 96.40, None]
mel_vals    = [88.80, 97.10, None]
x6          = np.arange(2)
w6          = 0.36

b1 = ax6.bar(x6 - w6/2, [87.82, 96.40], w6, label="Accuracy (%)",
             color=PALETTE["retained"], alpha=0.88, edgecolor="white")
b2 = ax6.bar(x6 + w6/2, [88.80, 97.10], w6, label="MEL Sensitivity (%)",
             color=PALETTE["correct"],  alpha=0.88, edgecolor="white")
for bars in [b1, b2]:
    for bar in bars:
        ax6.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.3,
                 f"{bar.get_height():.2f}%", ha="center", va="bottom",
                 fontsize=9.5, fontweight="bold")
# Risk reduction arrow
ax6.annotate("", xy=(0.75, 97.10), xytext=(0.75, 88.80),
             arrowprops=dict(arrowstyle="->", color="#C62828", lw=1.8))
ax6.text(0.78, 93, "+8.3%\nMEL Sens", fontsize=8.5, color="#C62828", fontweight="bold")

ax6.set(ylabel="Performance (%)", title="F  Triage Simulation Summary (τ*=0.30)",
        ylim=(82, 101))
ax6.set_xticks(x6); ax6.set_xticklabels(categories[:2], fontsize=10)
ax6.legend(fontsize=9); ax6.grid(axis="y", alpha=0.22)

# Caption note
fig.text(0.5, -0.01,
         "⚠ All results are retrospective test-fold simulations; τ* fixed on validation set only.",
         ha="center", fontsize=10, style="italic", color="#555555")


plt.savefig("../figures/Fig4_Uncertainty.png",
            dpi=300, bbox_inches="tight", facecolor="white")
print("✓ Fig4_Uncertainty.png saved")
