#!/usr/bin/env python3
"""
DermFusion — Figure 3: SOTA Comparison (4-panel)
=================================================
Reproduces Fig3_SOTA_Comparison.png from the paper.

Data exactly from Tab. sota_cls and Tab. sota_seg:

Classification (Tab. sota_cls):
  ResNet50       2016  81.3%   0.921   0.771   25.6M
  DenseNet121    2017  83.4%   0.944   0.792    8.0M
  EfficientNet-B4 2019 85.7%  0.961   0.814   19.3M
  ConvNeXtV2     2023  86.8%   0.965   0.829   88.5M
  Hybrid MedViT  2023  87.2%   0.975   0.842  112.0M
  MedMamba       2024  86.5%   0.969   0.831   28.4M
  DermFusion     2026  87.82%  0.9799  0.8497 124.3M  ← OURS

Segmentation (Tab. sota_seg):
  UNet++         2018  0.892  0.811  36.6M
  TransUNet      2021  0.903  0.829 105.0M
  Swin-Unet      2022  0.918  0.851 108.0M
  FAT-Net        2022  0.910  0.842  --
  SegFormer-B3   2022  0.911  0.844  47.3M
  DermFusion     2026  0.9359 0.8880 124.3M ← OURS
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import matplotlib.patches as mpatches
import warnings
warnings.filterwarnings("ignore")

# ─── Data ─────────────────────────────────────────────────────────────────────
CLS_METHODS = ["ResNet50\n[2016]", "DenseNet121\n[2017]",
               "EfficientNet-B4\n[2019]", "ConvNeXtV2\n[2023]",
               "Hybrid MedViT\n[2023]", "MedMamba\n[2024]",
               "DermFusion\n[Ours 2026]"]
CLS_ACC   = [81.3,  83.4,  85.7,  86.8,  87.2,  86.5,  87.82]
CLS_AUC   = [0.921, 0.944, 0.961, 0.965, 0.975, 0.969, 0.9799]
CLS_F1    = [0.771, 0.792, 0.814, 0.829, 0.842, 0.831, 0.8497]
CLS_PARAM = [25.6,  8.0,  19.3,  88.5, 112.0,  28.4,  124.3]

SEG_METHODS = ["UNet++\n[2018]", "TransUNet\n[2021]",
               "Swin-Unet\n[2022]", "FAT-Net\n[2022]",
               "SegFormer-B3\n[2022]", "DermFusion\n[Ours 2026]"]
SEG_DICE = [0.892, 0.903, 0.918, 0.910, 0.911, 0.9359]
SEG_IOU  = [0.811, 0.829, 0.851, 0.842, 0.844, 0.8880]
SEG_PARAM= [36.6, 105.0, 108.0,  None,  47.3, 124.3]

def bar_color(values, ours_idx):
    """Blue for baselines, gold for ours."""
    return ["#1565C0" if i != ours_idx else "#F9A825" for i in range(len(values))]

def add_labels(ax, bars, fmt="{:.2f}", offset=0.0, fontsize=9.5):
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + offset,
                fmt.format(h), ha="center", va="bottom",
                fontsize=fontsize, fontweight="bold")

# ─── Figure ──────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(18, 10), facecolor="white")
gs  = GridSpec(2, 2, figure=fig, hspace=0.48, wspace=0.32)

# ── A: Classification Accuracy ────────────────────────────────────────────
ax1 = fig.add_subplot(gs[0, 0])
x1  = np.arange(len(CLS_METHODS))
bars1 = ax1.bar(x1, CLS_ACC, color=bar_color(CLS_ACC, -1),
                edgecolor="white", lw=0.5, alpha=0.90, width=0.62)
ax1.axhline(87.82, color="#F9A825", lw=1.8, ls="--", alpha=0.7)
ax1.set_ylim(79, 89.5)
ax1.set_xticks(x1); ax1.set_xticklabels(CLS_METHODS, fontsize=9.5)
ax1.set_ylabel("Classification Accuracy (%)", fontsize=11, fontweight="bold")
ax1.set_title("A  Classification Accuracy (HAM10000)", fontsize=12, fontweight="bold")
add_labels(ax1, bars1, fmt="{:.2f}%", offset=0.05, fontsize=9)
ax1.grid(axis="y", alpha=0.25)

# ── B: ROC-AUC ───────────────────────────────────────────────────────────
ax2 = fig.add_subplot(gs[0, 1])
bars2 = ax2.bar(x1, CLS_AUC, color=bar_color(CLS_AUC, -1),
                edgecolor="white", lw=0.5, alpha=0.90, width=0.62)
ax2.axhline(0.9799, color="#F9A825", lw=1.8, ls="--", alpha=0.7)
ax2.set_ylim(0.910, 0.993)
ax2.set_xticks(x1); ax2.set_xticklabels(CLS_METHODS, fontsize=9.5)
ax2.set_ylabel("ROC-AUC", fontsize=11, fontweight="bold")
ax2.set_title("B  ROC-AUC (HAM10000)", fontsize=12, fontweight="bold")
add_labels(ax2, bars2, fmt="{:.4f}", offset=0.0005, fontsize=8.8)
ax2.grid(axis="y", alpha=0.25)

# ── C: Segmentation Dice ──────────────────────────────────────────────────
ax3 = fig.add_subplot(gs[1, 0])
x3   = np.arange(len(SEG_METHODS))
bars3 = ax3.bar(x3, SEG_DICE, color=bar_color(SEG_DICE, -1),
                edgecolor="white", lw=0.5, alpha=0.90, width=0.62)
ax3.axhline(0.9359, color="#F9A825", lw=1.8, ls="--", alpha=0.7)
ax3.set_ylim(0.875, 0.950)
ax3.set_xticks(x3); ax3.set_xticklabels(SEG_METHODS, fontsize=9.5)
ax3.set_ylabel("Dice Coefficient", fontsize=11, fontweight="bold")
ax3.set_title("C  Segmentation Dice (ISIC 2018)", fontsize=12, fontweight="bold")
add_labels(ax3, bars3, fmt="{:.4f}", offset=0.0003, fontsize=9)
ax3.grid(axis="y", alpha=0.25)

# ── D: IoU ────────────────────────────────────────────────────────────────
ax4 = fig.add_subplot(gs[1, 1])
bars4 = ax4.bar(x3, SEG_IOU, color=bar_color(SEG_IOU, -1),
                edgecolor="white", lw=0.5, alpha=0.90, width=0.62)
ax4.axhline(0.8880, color="#F9A825", lw=1.8, ls="--", alpha=0.7)
ax4.set_ylim(0.795, 0.905)
ax4.set_xticks(x3); ax4.set_xticklabels(SEG_METHODS, fontsize=9.5)
ax4.set_ylabel("IoU Score", fontsize=11, fontweight="bold")
ax4.set_title("D  IoU Score (ISIC 2018)", fontsize=12, fontweight="bold")
add_labels(ax4, bars4, fmt="{:.4f}", offset=0.0004, fontsize=9)
ax4.grid(axis="y", alpha=0.25)

# Legend
ours_patch = mpatches.Patch(color="#F9A825", label="DermFusion (Ours) — split-controlled")
base_patch = mpatches.Patch(color="#1565C0", label="Baselines — indicative comparison")
fig.legend(handles=[ours_patch, base_patch], fontsize=11,
           loc="lower center", ncol=2, bbox_to_anchor=(0.5, -0.03),
           framealpha=0.9)



plt.savefig("../figures/Fig3_SOTA_Comparison.png",
            dpi=300, bbox_inches="tight", facecolor="white")
print("✓ Fig3_SOTA_Comparison.png saved")
