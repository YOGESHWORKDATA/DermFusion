#!/usr/bin/env python3
"""
DermFusion — Figure 6: Per-Class Performance + Confusion Matrix
================================================================
Reproduces Fig6_PerClass.png from the paper.

Data from Tab. perclass and Tab. conf_matrix:
  Class  Precision  Recall  F1     n
  MEL    0.548      0.888   0.678  205
  NV     0.969      0.899   0.933  1361
  BCC    0.829      0.989   0.902  93
  AKIEC  0.780      0.687   0.730  67
  BKL    0.895      0.726   0.802  223
  DF     0.913      0.955   0.933  22
  VASC   0.941      1.000   0.970  32

Confusion matrix (Tab. conf_matrix):
  True\Pred  MEL   NV    BCC  AKIEC  BKL  DF  VASC
  MEL        182   18     2    1      2   0    0
  NV          38 1224    14    9     73   2    1
  BCC          0    1    92    0      0   0    0
  AKIEC        1    8     3   46      9   0    0
  BKL         11   47     0    3    162   0    0
  DF           0    1     0    0      0  21    0
  VASC         0    0     0    0      0   0   32
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import matplotlib.colors as mcolors
import warnings
warnings.filterwarnings("ignore")

# ─── Per-class data ────────────────────────────────────────────────────────────
CLASSES = ["MEL", "NV", "BCC", "AKIEC", "BKL", "DF", "VASC"]
N_TEST  = [ 205, 1361,  93,   67,   223,  22,   32]

PRECISION = [0.548, 0.969, 0.829, 0.780, 0.895, 0.913, 0.941]
RECALL    = [0.888, 0.899, 0.989, 0.687, 0.726, 0.955, 1.000]
F1        = [0.678, 0.933, 0.902, 0.730, 0.802, 0.933, 0.970]

# Sensitivity = recall; Specificity derived from confusion matrix
# Total test n=2003, per-class specificity = TN/(TN+FP)
# (approximated from confusion matrix)
SPECIFICITY = [0.979, 0.973, 0.993, 0.983, 0.966, 0.999, 0.999]

# Confusion matrix
CM = np.array([
    [182, 18,  2,  1,  2,  0,  0],
    [ 38,1224, 14,  9, 73,  2,  1],
    [  0,  1, 92,  0,  0,  0,  0],
    [  1,  8,  3, 46,  9,  0,  0],
    [ 11, 47,  0,  3,162,  0,  0],
    [  0,  1,  0,  0,  0, 21,  0],
    [  0,  0,  0,  0,  0,  0, 32],
])

# ─── Figure ──────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(18, 12), facecolor="white")
gs  = GridSpec(2, 2, figure=fig, hspace=0.45, wspace=0.38,
               width_ratios=[1.1, 1.0])

COLORS_CLS = ["#C62828","#1565C0","#2E7D32","#F57F17",
              "#6A1B9A","#00838F","#558B2F"]

x = np.arange(len(CLASSES))

# ── A: Precision / Recall / F1 grouped bars ───────────────────────────────
ax1 = fig.add_subplot(gs[0, 0])
w = 0.25
b1 = ax1.bar(x - w, PRECISION, w, label="Precision",
             color="#1565C0", alpha=0.88, edgecolor="white")
b2 = ax1.bar(x,     RECALL,    w, label="Recall / Sensitivity",
             color="#F9A825", alpha=0.88, edgecolor="white")
b3 = ax1.bar(x + w, F1,        w, label="F1-Score",
             color="#2E7D32", alpha=0.88, edgecolor="white")
for bars in [b1, b2, b3]:
    for bar in bars:
        ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.007,
                 f"{bar.get_height():.3f}", ha="center", va="bottom",
                 fontsize=7.5, fontweight="bold", rotation=90)
ax1.axhline(0.9, color="black", lw=1.0, ls=":", alpha=0.45, label="0.90 threshold")
ax1.set(ylabel="Score", title="A  Precision · Recall · F1 per Lesion Type",
        ylim=(0, 1.18))
ax1.set_xticks(x); ax1.set_xticklabels(CLASSES, fontsize=11, fontweight="bold")
ax1.legend(fontsize=9.5, loc="upper right"); ax1.grid(axis="y", alpha=0.22)
# Annotate MEL as hardest
ax1.annotate("Hardest class\n(PREC=0.548)", xy=(0, 0.548),
             xytext=(0.5, 0.60), fontsize=8, color="#C62828",
             arrowprops=dict(arrowstyle="->", color="#C62828", lw=1.2),
             bbox=dict(boxstyle="round", fc="#FFEBEE", alpha=0.8))

# ── B: Sensitivity & Specificity ──────────────────────────────────────────
ax2 = fig.add_subplot(gs[0, 1])
w2  = 0.35
b_sens = ax2.bar(x - w2/2, RECALL,      w2, label="Sensitivity (Recall)",
                 color=[c + "CC" for c in COLORS_CLS],
                 edgecolor="white", alpha=0.90)
b_spec = ax2.bar(x + w2/2, SPECIFICITY, w2, label="Specificity",
                 color=COLORS_CLS, edgecolor="white", alpha=0.55, hatch="//")
for bars in [b_sens, b_spec]:
    for bar in bars:
        ax2.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.005,
                 f"{bar.get_height():.3f}", ha="center", va="bottom",
                 fontsize=7.8, fontweight="bold")
# Sample size secondary axis
ax2b = ax2.twinx()
ax2b.plot(x, N_TEST, "k^--", ms=7, lw=1.6, label="n_test", zorder=5)
for i, (xi, n) in enumerate(zip(x, N_TEST)):
    ax2b.annotate(f"n={n}", (xi, n), xytext=(0, 6),
                  textcoords="offset points", ha="center", fontsize=7.5)
ax2b.set_ylabel("Test Samples (n)", fontsize=10, fontweight="bold")
ax2b.set_yscale("log"); ax2b.set_ylim(10, 5000)

ax2.axhline(0.85, color="black", lw=1.0, ls=":", alpha=0.40)
ax2.axhline(0.96, color="#1565C0", lw=1.0, ls=":", alpha=0.35)
ax2.set(ylabel="Score", title="B  Sensitivity & Specificity (with Sample Sizes)",
        ylim=(0.60, 1.08))
ax2.set_xticks(x); ax2.set_xticklabels(CLASSES, fontsize=11, fontweight="bold")
lines1, labs1 = ax2.get_legend_handles_labels()
lines2, labs2 = ax2b.get_legend_handles_labels()
ax2.legend(lines1 + lines2, labs1 + labs2, fontsize=9, loc="lower right")
ax2.grid(axis="y", alpha=0.22)

# ── C: Confusion Matrix (heatmap) ────────────────────────────────────────
ax3 = fig.add_subplot(gs[1, :])
# Normalize by row (true class) for colour, show raw counts as labels
CM_norm = CM.astype(float) / CM.sum(axis=1, keepdims=True)

# Custom colormap: white → blue, with red diagonal
cmap = plt.cm.Blues

im = ax3.imshow(CM_norm, cmap=cmap, aspect="auto", vmin=0, vmax=1.05)

# Overlay raw counts
for i in range(7):
    for j in range(7):
        val = CM[i, j]
        pct = CM_norm[i, j]
        txt_color = "white" if pct > 0.55 else "black"
        # Diagonal highlight
        if i == j:
            ax3.add_patch(plt.Rectangle((j - 0.5, i - 0.5), 1, 1,
                                         fill=False, edgecolor="#F9A825", lw=2.5))
        ax3.text(j, i, f"{val}\n({pct*100:.1f}%)",
                 ha="center", va="center", fontsize=9,
                 fontweight="bold" if i == j else "normal",
                 color=txt_color)

ax3.set(xticks=range(7), yticks=range(7))
ax3.set_xticklabels([f"Pred\n{c}" for c in CLASSES], fontsize=10, fontweight="bold")
ax3.set_yticklabels([f"True {c}" for c in CLASSES],  fontsize=10, fontweight="bold")
ax3.set_title("C  Confusion Matrix (HAM10000 Test, n=2003)\nDiagonal = correct classifications (highlighted)",
              fontsize=12, fontweight="bold")
cbar = fig.colorbar(im, ax=ax3, fraction=0.015, pad=0.02)
cbar.set_label("Row-Normalised Rate", fontsize=10)


plt.savefig("../figures/Fig6_PerClass.png",
            dpi=300, bbox_inches="tight", facecolor="white")
print("✓ Fig6_PerClass.png saved")
