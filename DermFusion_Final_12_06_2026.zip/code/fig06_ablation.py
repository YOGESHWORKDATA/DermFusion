#!/usr/bin/env python3
"""
DermFusion — Figure 5: Component-Wise Ablation Study
=====================================================
Reproduces Fig5_Ablation.png from the paper.

Data exactly from Tab. extended_ablation:
  Full DermFusion         87.82%  0.9799   0.9359  0.1575
  w/o Cross-Attention     85.90   0.9602   0.8872  0.214   (−1.92, −0.0197, −0.0487)
  w/o Seg. Branch         86.40   0.9654   N/A     0.208   (−1.42, −0.0145)
  w/o Deep Supervision    86.72   0.9711   0.9142  0.194   (−1.10, −0.0088, −0.0217)
  w/o MC Dropout          87.11   0.9750   0.9330  0.241   (−0.71, −0.0049, −0.0029)
  w/o Temp. Calibration   87.20   0.9798   0.9351  0.312   (−0.62, −0.0001, −0.0008)
  w/o Uncertainty Weight  86.84   0.9719   0.9210  0.226   (−0.98, −0.0080, −0.0149)
"""

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
import warnings
warnings.filterwarnings("ignore")

# ─── Data from Tab. extended_ablation ─────────────────────────────────────────
CONFIGS = [
    "Full\nDermFusion",
    "w/o Cross-\nAttention",
    "w/o Seg.\nBranch",
    "w/o Deep\nSupervision",
    "w/o MC\nDropout",
    "w/o Temp.\nCalibration",
    "w/o Uncertainty\nWeighting",
]
ACC  = [87.82, 85.90, 86.40, 86.72, 87.11, 87.20, 86.84]
AUC  = [0.9799, 0.9602, 0.9654, 0.9711, 0.9750, 0.9798, 0.9719]
DICE = [0.9359, 0.8872,   None, 0.9142, 0.9330, 0.9351, 0.9210]
ECE  = [0.1575, 0.214,  0.208,  0.194,  0.241,  0.312,  0.226]

ACC_DROP  = [0,     -1.92, -1.42, -1.10, -0.71, -0.62, -0.98]
AUC_DROP  = [0,  -0.0197,-0.0145,-0.0088,-0.0049,-0.0001,-0.0080]
DICE_DROP = [0,  -0.0487,  None, -0.0217,-0.0029,-0.0008,-0.0149]
ECE_SPIKE = [0,   0.0565, 0.0505, 0.0365, 0.0835, 0.1545, 0.0685]

# Color: ours gold, ablated blue, highest-impact orange
FULL_COLOR   = "#F9A825"
BASE_COLOR   = "#1565C0"
WORST_COLOR  = "#C62828"

def get_colors(values, best_idx=0):
    colors = [BASE_COLOR] * len(values)
    colors[best_idx] = FULL_COLOR
    # Worst = largest negative delta (index 1 for cross-attn)
    return colors

N = len(CONFIGS)
x = np.arange(N)

def add_delta_labels(ax, drops, y_bases, fmt="{:+.2f}", fontsize=8.5, color="#555"):
    for i, (d, yb) in enumerate(zip(drops, y_bases)):
        if d is not None and d != 0:
            ax.text(i, yb + 0.001, fmt.format(d), ha="center", va="bottom",
                    fontsize=fontsize, color=color, fontweight="bold",
                    rotation=0)

# ─── Figure ──────────────────────────────────────────────────────────────────
fig = plt.figure(figsize=(18, 10), facecolor="white")
gs  = GridSpec(2, 2, figure=fig, hspace=0.48, wspace=0.32)

# ── A: Accuracy ───────────────────────────────────────────────────────────
ax1 = fig.add_subplot(gs[0, 0])
colors_acc = [FULL_COLOR if i == 0 else (WORST_COLOR if ACC_DROP[i] == min(ACC_DROP) else BASE_COLOR)
              for i in range(N)]
bars1 = ax1.bar(x, ACC, color=colors_acc, edgecolor="white", lw=0.5, alpha=0.88, width=0.62)
ax1.axhline(87.82, color=FULL_COLOR, lw=1.6, ls="--", alpha=0.65)
for bar, drop in zip(bars1, ACC_DROP):
    h = bar.get_height()
    lbl = f"{h:.2f}" if drop == 0 else f"{h:.2f}\n({drop:+.2f})"
    ax1.text(bar.get_x() + bar.get_width()/2, h + 0.06, lbl,
             ha="center", va="bottom", fontsize=8.5, fontweight="bold")
ax1.set(xlabel="", ylabel="Accuracy (%)", title="A  Classification Accuracy",
        ylim=(84.5, 89.5))
ax1.set_xticks(x); ax1.set_xticklabels(CONFIGS, fontsize=9.5)
ax1.grid(axis="y", alpha=0.22)
ax1.text(0.98, 0.97, "Cross-attention removal\nlargest drop (−1.92%)",
         transform=ax1.transAxes, ha="right", va="top", fontsize=8.5,
         color=WORST_COLOR, bbox=dict(boxstyle="round", fc="#FFEBEE", alpha=0.8))

# ── B: AUC ────────────────────────────────────────────────────────────────
ax2 = fig.add_subplot(gs[0, 1])
colors_auc = [FULL_COLOR if i == 0 else (WORST_COLOR if AUC_DROP[i] == min(AUC_DROP) else BASE_COLOR)
              for i in range(N)]
bars2 = ax2.bar(x, AUC, color=colors_auc, edgecolor="white", lw=0.5, alpha=0.88, width=0.62)
ax2.axhline(0.9799, color=FULL_COLOR, lw=1.6, ls="--", alpha=0.65)
for bar, drop in zip(bars2, AUC_DROP):
    h = bar.get_height()
    lbl = f"{h:.4f}" if drop == 0 else f"{h:.4f}\n({drop:+.4f})"
    ax2.text(bar.get_x() + bar.get_width()/2, h + 0.0004, lbl,
             ha="center", va="bottom", fontsize=8.0, fontweight="bold")
ax2.set(xlabel="", ylabel="ROC-AUC", title="B  ROC-AUC",
        ylim=(0.955, 0.988))
ax2.set_xticks(x); ax2.set_xticklabels(CONFIGS, fontsize=9.5)
ax2.grid(axis="y", alpha=0.22)

# ── C: Dice Coefficient ──────────────────────────────────────────────────
ax3 = fig.add_subplot(gs[1, 0])
dice_plot = [d if d is not None else 0 for d in DICE]
hatches = ["" if d is not None else "//" for d in DICE]
colors_dice = [FULL_COLOR if i == 0 else (WORST_COLOR if DICE_DROP[i] == min([v for v in DICE_DROP if v is not None])
               else BASE_COLOR) for i in range(N)]
bars3 = ax3.bar(x, dice_plot, color=colors_dice, edgecolor="white",
                lw=0.5, alpha=0.88, width=0.62)
# Hatch the N/A bar
bars3[2].set_hatch("//"); bars3[2].set_alpha(0.30)
ax3.axhline(0.9359, color=FULL_COLOR, lw=1.6, ls="--", alpha=0.65)
for i, (bar, d, drop) in enumerate(zip(bars3, DICE, DICE_DROP)):
    if d is None:
        ax3.text(i, 0.02, "N/A", ha="center", va="bottom",
                 fontsize=10, fontweight="bold", color="#888")
    else:
        lbl = f"{d:.4f}" if drop == 0 else f"{d:.4f}\n({drop:+.4f})"
        ax3.text(bar.get_x() + bar.get_width()/2, d + 0.002, lbl,
                 ha="center", va="bottom", fontsize=8.0, fontweight="bold")
ax3.set(xlabel="", ylabel="Dice Coefficient", title="C  Segmentation Dice",
        ylim=(0.86, 0.950))
ax3.set_xticks(x); ax3.set_xticklabels(CONFIGS, fontsize=9.5)
ax3.grid(axis="y", alpha=0.22)

# ── D: ECE ────────────────────────────────────────────────────────────────
ax4 = fig.add_subplot(gs[1, 1])
colors_ece = [FULL_COLOR if i == 0 else (WORST_COLOR if ECE_SPIKE[i] == max(ECE_SPIKE) else BASE_COLOR)
              for i in range(N)]
bars4 = ax4.bar(x, ECE, color=colors_ece, edgecolor="white", lw=0.5, alpha=0.88, width=0.62)
ax4.axhline(0.1575, color=FULL_COLOR, lw=1.6, ls="--", alpha=0.65)
for bar, ece_val, spike in zip(bars4, ECE, ECE_SPIKE):
    h = bar.get_height()
    lbl = f"{h:.4f}" if spike == 0 else f"{h:.4f}\n(+{spike:.4f})"
    ax4.text(bar.get_x() + bar.get_width()/2, h + 0.003, lbl,
             ha="center", va="bottom", fontsize=8.0, fontweight="bold")
ax4.set(xlabel="", ylabel="ECE (↓ better)", title="D  Expected Calibration Error",
        ylim=(0.13, 0.34))
ax4.set_xticks(x); ax4.set_xticklabels(CONFIGS, fontsize=9.5)
ax4.grid(axis="y", alpha=0.22)
ax4.text(0.98, 0.97, "Temp. calibration removal\nworst ECE spike (+0.1545)",
         transform=ax4.transAxes, ha="right", va="top", fontsize=8.5,
         color=WORST_COLOR, bbox=dict(boxstyle="round", fc="#FFEBEE", alpha=0.8))



plt.savefig("../figures/Fig5_Ablation.png",
            dpi=300, bbox_inches="tight", facecolor="white")
print("✓ Fig5_Ablation.png saved")
