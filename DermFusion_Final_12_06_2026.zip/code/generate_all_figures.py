#!/usr/bin/env python3
"""
DermFusion — Master Figure Generation Script
=============================================
Run this single script to regenerate ALL publication figures.
All data values are exact from the paper's tables and results.

Usage:
    cd DermFusion_Project/code
    python generate_all_figures.py

Output: ../figures/  (all PNGs written there)

Requirements: See requirements.txt
    pip install -r requirements.txt
"""

import subprocess
import sys
import os
import time

# ─── Script registry ──────────────────────────────────────────────────────────
SCRIPTS = [
    ("fig01_training_dynamics.py",    "Fig 1  — Training Dynamics (45 epochs)"),
    ("fig02_calibration_plot.py",     "Fig 2  — Calibration Reliability Diagram"),
    ("fig03_roc_curves.py",           "Fig 3  — Per-Class ROC Curves"),
    ("fig04_sota_comparison.py",      "Fig 4  — SOTA Comparison (4-panel)"),
    ("fig05_uncertainty.py",          "Fig 5  — Uncertainty Quantification (6-panel)"),
    ("fig06_ablation.py",             "Fig 6  — Component-Wise Ablation (4-panel)"),
    ("fig07_perclass.py",             "Fig 7  — Per-Class Performance + Confusion Matrix"),
    ("fig08_uncertainty_histogram.py","Fig 8  — Uncertainty Histogram + CDF"),
]

SEPARATOR = "=" * 72

def run_script(script_path, description):
    start = time.time()
    result = subprocess.run(
        [sys.executable, script_path],
        capture_output=True, text=True
    )
    elapsed = time.time() - start
    ok = result.returncode == 0
    status = "✓" if ok else "✗"
    print(f"  {status}  {description:<52} [{elapsed:.1f}s]")
    if not ok:
        print(f"     STDERR: {result.stderr.strip()[:200]}")
    return ok

def check_requirements():
    """Verify all required packages are importable."""
    required = [
        ("numpy",       "numpy"),
        ("matplotlib",  "matplotlib"),
        ("scipy",       "scipy"),
        ("seaborn",     "seaborn"),
    ]
    missing = []
    for pkg, imp in required:
        try:
            __import__(imp)
        except ImportError:
            missing.append(pkg)
    if missing:
        print(f"\n⚠  Missing packages: {', '.join(missing)}")
        print("   Run:  pip install -r requirements.txt\n")
        sys.exit(1)

def main():
    print(SEPARATOR)
    print("  DermFusion — Publication Figure Generation")
    print("  All data values match paper tables exactly")
    print(SEPARATOR)

    # Ensure we are in the code directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    # Ensure output directory exists
    figures_dir = os.path.join(script_dir, "..", "figures")
    os.makedirs(figures_dir, exist_ok=True)

    check_requirements()

    print(f"\n  Output → {os.path.abspath(figures_dir)}\n")

    passed = 0
    failed_list = []

    for script, desc in SCRIPTS:
        ok = run_script(script, desc)
        if ok:
            passed += 1
        else:
            failed_list.append(script)

    print(f"\n{SEPARATOR}")
    print(f"  {passed}/{len(SCRIPTS)} figures generated successfully")
    if failed_list:
        print(f"  Failed: {', '.join(failed_list)}")
    else:
        print("  All figures complete. Ready for LaTeX compilation.")
    print(SEPARATOR)

    # List generated files
    print("\n  Generated files:")
    for f in sorted(os.listdir(figures_dir)):
        if f.endswith(".png"):
            size_kb = os.path.getsize(os.path.join(figures_dir, f)) // 1024
            print(f"    {f:<45} {size_kb:>5} KB")

if __name__ == "__main__":
    main()
